// values.h
#ifndef VALUES_H
#define VALUES_H

class Values {
public:
  static const int steps = 200;
  float angle;
  float RPM;
};

#endif // VALUES_H